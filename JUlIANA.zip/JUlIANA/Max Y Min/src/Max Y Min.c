/*
 ============================================================================
 Name        : Max.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {

	int contador=0;
	int numero;
	int numeroMax;
	int numeroMin;

	for(contador=0; contador<5;contador++){

		printf("Ingrese un numero:");
		scanf("%d",&numero);

		if(contador==0 || numero>numeroMax)
		{
			numeroMax=numero;
		}
		if (contador==0 || numero<numeroMin)
		{
			numeroMin=numero;
		}



	}
	printf("El numero max es %d, y el minimo es %d ",numeroMax, numeroMin);
	return EXIT_SUCCESS;

}
