/*
 ============================================================================
 Name        : Clase.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int numero1;
	int numero2;
	/*printf("Ingrese el primer numero: \n");
	scanf("%d",&numero1);
	printf("Ingrese el segundo numero: \n");
	scanf("%d",&numero2);
	int resultado =numero1+numero2;
	printf("El resultado es: %d", resultado);*/
	int flag =0;
	int numeroAcumulador=0;
	while(flag==0){
		printf("Ingrese un numero:\n");
		scanf("%d",&numero1);
		numeroAcumulador=numero1+numeroAcumulador;
		printf("Desea continuar cargando? Ingrese 0 \n");
		scanf("%d",&flag);
	}

	printf("El resultado es: %d",numeroAcumulador);
	return EXIT_SUCCESS;
}
